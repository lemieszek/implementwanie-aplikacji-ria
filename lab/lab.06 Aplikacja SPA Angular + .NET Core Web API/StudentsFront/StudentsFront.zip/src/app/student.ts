export class Student {
    id: number;
    index: number;
    firstName: string;
    lastName: string;
   }
   